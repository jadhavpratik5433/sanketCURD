using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using WebApp.Data;
using WebApp.Models;

namespace WebApp.Pages.Book
{
    public class EditModel : PageModel
    {
        private readonly AppDbContext context;

        public EditModel(AppDbContext context)
        {
            this.context = context;
        }

        [BindProperty]
        public Books Books { get; set; } = default!;
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return RedirectToPage("./Index");
            }

            var books = new List<Books>
            {
                new Books { BookId = 1, BookTitle = "ABC", BookAuthor = "PQR", BookDescription = "StoryBook" },
                new Books { BookId = 2, BookTitle = "DEF", BookAuthor = "LMN", BookDescription = "Sci-Fi" },
                new Books { BookId = 3, BookTitle = "GHI", BookAuthor = "XYZ", BookDescription = "Horror" }
            };
            var bookDetail = books.FirstOrDefault(b => b.BookId == id);

            if (bookDetail != null)
            {
                Books = bookDetail;
                return Page();
            }
            else
            {
                return RedirectToPage("./Index");
            }
            //if(id == null)
            //{
            //    return RedirectToPage("./Index");
            //}

            //var books = await context.Books.FirstOrDefaultAsync(e => e.BookId == id);

            //if(books == null)
            //{
            //    return RedirectToPage("./Index");
            //}
            //else
            //{
            //    Books = books;
            //    return Page();
            //}
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            //context.Books.Update(Books);
            //await context.SaveChangesAsync();
            TempData["UpdateBooks"] = JsonConvert.SerializeObject(Books);
            return RedirectToPage("./Index");
        }
    }
}
