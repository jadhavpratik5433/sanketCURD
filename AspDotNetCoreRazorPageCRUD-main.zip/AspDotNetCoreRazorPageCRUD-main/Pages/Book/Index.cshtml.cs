using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Net;
using WebApp.Data;
using WebApp.Models;

namespace WebApp.Pages.Book
{
    public class IndexModel : PageModel
    {
        private readonly AppDbContext context;

        public IndexModel(AppDbContext context)
        {
            this.context = context;
        }
        public IList<Books> Books { get; set; } = default!;
        public async Task OnGetAsync()
        {
            Books nBooks = null;
            Books uBooks = null;
            Books dBooks = null;

            //Static book data
            var books = new List<Books>
            {
                new Books { BookId = 1, BookTitle = "ABC", BookAuthor = "PQR", BookDescription = "StoryBook" },
                new Books { BookId = 2, BookTitle = "DEF", BookAuthor = "LMN", BookDescription = "Sci-Fi" },
                new Books { BookId = 3, BookTitle = "GHI", BookAuthor = "XYZ", BookDescription = "Horror" }
            };


            //Add New Functinality
            if (TempData["NewBooks"] != null)
            {
                var newBooks = TempData["NewBooks"].ToString();
                nBooks = new Books();
                nBooks = JsonConvert.DeserializeObject<Books>(newBooks);
                
                if (nBooks != null)
                {
                    books.Add(nBooks);                  
                }
            }
           

            //Update Functinality
            if (TempData["UpdateBooks"] != null)
            {
                var updateBooks = TempData["UpdateBooks"].ToString();
                uBooks = new Books();
                uBooks = JsonConvert.DeserializeObject<Books>(updateBooks);
                int index = books.FindIndex(b => b.BookId == uBooks.BookId);


                if (index != -1)
                {                    
                    books[index] = uBooks;
                }                
            }


            //Delete Functionality           
            if (TempData["DeleteBooks"] != null)
            {
                var deleteBooks = TempData["DeleteBooks"].ToString();
                dBooks = new Books();
                dBooks = JsonConvert.DeserializeObject<Books>(deleteBooks);
                int index = books.FindIndex(b => b.BookId == dBooks.BookId);


                if (index != -1)
                {
                    books.RemoveAt(index);
                }
            }

            Books = books;
        }
    }
}
